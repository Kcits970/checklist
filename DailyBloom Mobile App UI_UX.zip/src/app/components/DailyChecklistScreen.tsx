import { CheckCircle2, Circle, Flame, Home, BarChart3, ListTodo } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router';

const todayHabits = [
  { id: 1, title: 'Drink water', completed: false },
  { id: 2, title: 'Open the window', completed: false },
  { id: 3, title: '1 minute stretch', completed: false },
  { id: 4, title: 'Short walk', completed: false },
];

export default function DailyChecklistScreen() {
  const [habits, setHabits] = useState(todayHabits);
  const navigate = useNavigate();

  const toggleHabit = (id: number) => {
    setHabits(habits.map(h => h.id === id ? { ...h, completed: !h.completed } : h));
  };

  const completedCount = habits.filter(h => h.completed).length;
  const totalCount = habits.length;
  const progress = (completedCount / totalCount) * 100;
  const streak = 7;

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 px-6 py-8 pb-24">
        <div className="max-w-md mx-auto">
          <div className="mb-6">
            <h1 className="text-[#2D3436] mb-4" style={{ fontSize: '24px' }}>
              Today's Habits
            </h1>

            <div className="bg-gradient-to-br from-[#6BAF8D] to-[#5DA581] rounded-2xl p-5 text-white shadow-lg mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p style={{ fontSize: '14px', fontWeight: 400, opacity: 0.9 }}>Daily Progress</p>
                  <p style={{ fontSize: '28px' }}>
                    {completedCount} / {totalCount}
                  </p>
                </div>
                <div className="flex items-center gap-2 bg-white/20 rounded-full px-4 py-2">
                  <Flame className="w-5 h-5" />
                  <span style={{ fontSize: '16px' }}>{streak} day streak</span>
                </div>
              </div>

              <div className="bg-white/20 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-white h-full rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {habits.map((habit) => (
              <button
                key={habit.id}
                onClick={() => toggleHabit(habit.id)}
                className={`w-full p-4 rounded-2xl border-2 transition-all flex items-center gap-4 ${
                  habit.completed
                    ? 'bg-[#6BAF8D]/5 border-[#6BAF8D]'
                    : 'bg-white border-[#6BAF8D]/15'
                }`}
              >
                {habit.completed ? (
                  <CheckCircle2 className="w-6 h-6 text-[#6BAF8D] shrink-0" strokeWidth={2} />
                ) : (
                  <Circle className="w-6 h-6 text-[#6B7280] shrink-0" strokeWidth={2} />
                )}
                <span
                  className={`text-left ${
                    habit.completed ? 'text-[#6B7280] line-through' : 'text-[#2D3436]'
                  }`}
                  style={{ fontSize: '16px' }}
                >
                  {habit.title}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#6BAF8D]/15 px-6 py-4 shadow-[0_-4px_12px_rgba(0,0,0,0.05)]">
        <div className="max-w-md mx-auto flex justify-around">
          <button className="flex flex-col items-center gap-1 text-[#6BAF8D]">
            <Home className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '12px', fontWeight: 500 }}>Home</span>
          </button>
          <button
            onClick={() => navigate('/daily-checklist')}
            className="flex flex-col items-center gap-1 text-[#6BAF8D]"
          >
            <ListTodo className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '12px', fontWeight: 500 }}>Today</span>
          </button>
          <button
            onClick={() => navigate('/monthly-report')}
            className="flex flex-col items-center gap-1 text-[#6B7280]"
          >
            <BarChart3 className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '12px', fontWeight: 500 }}>Report</span>
          </button>
        </div>
      </div>
    </div>
  );
}
