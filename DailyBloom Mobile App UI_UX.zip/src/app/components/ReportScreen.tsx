import { Award, TrendingUp, Calendar, ChevronRight, Droplet, Wind, Sparkles, Footprints } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, LineChart, Line, CartesianGrid, Tooltip } from 'recharts';
import { useState } from 'react';
import BottomNav from './BottomNav';
import DetailModal from './DetailModal';

const weeklyData = [
  { day: '월', completed: 3 },
  { day: '화', completed: 4 },
  { day: '수', completed: 2 },
  { day: '목', completed: 4 },
  { day: '금', completed: 3 },
  { day: '토', completed: 4 },
  { day: '일', completed: 4 },
];

const categoryDetailData = {
  water: {
    name: '수분 섭취',
    icon: Droplet,
    color: '#6BAF8D',
    completed: 26,
    total: 30,
    streak: 12,
    monthlyData: [
      { week: '1주차', count: 5 },
      { week: '2주차', count: 7 },
      { week: '3주차', count: 6 },
      { week: '4주차', count: 8 },
    ],
    tips: [
      '아침에 일어나자마자 물 한 잔 마시기',
      '스마트폰 알림 설정하여 2시간마다 수분 섭취',
      '물병을 항상 눈에 보이는 곳에 두기',
    ],
  },
  air: {
    name: '환기',
    icon: Wind,
    color: '#A8D5BA',
    completed: 22,
    total: 30,
    streak: 8,
    monthlyData: [
      { week: '1주차', count: 4 },
      { week: '2주차', count: 6 },
      { week: '3주차', count: 5 },
      { week: '4주차', count: 7 },
    ],
    tips: [
      '아침과 저녁 하루 2회 환기하기',
      '환기 시간을 루틴에 포함시키기',
      '공기가 맑은 시간대 선택하기',
    ],
  },
  stretch: {
    name: '스트레칭',
    icon: Sparkles,
    color: '#81C784',
    completed: 24,
    total: 30,
    streak: 10,
    monthlyData: [
      { week: '1주차', count: 5 },
      { week: '2주차', count: 6 },
      { week: '3주차', count: 6 },
      { week: '4주차', count: 7 },
    ],
    tips: [
      '업무 중간중간 목과 어깨 스트레칭',
      '스트레칭 루틴 영상 따라하기',
      '앉아있을 때마다 허리 펴기',
    ],
  },
  walk: {
    name: '산책',
    icon: Footprints,
    color: '#4CAF50',
    completed: 18,
    total: 30,
    streak: 5,
    monthlyData: [
      { week: '1주차', count: 3 },
      { week: '2주차', count: 5 },
      { week: '3주차', count: 4 },
      { week: '4주차', count: 6 },
    ],
    tips: [
      '점심 식사 후 10분 산책하기',
      '날씨 좋은 날 조금 더 걷기',
      '좋아하는 음악과 함께 산책하기',
    ],
  },
};

export default function ReportScreen() {
  const [selectedDetail, setSelectedDetail] = useState<keyof typeof categoryDetailData | null>(null);
  const successRate = 82;
  const totalCompleted = 94;
  const bestCategory = '수분 섭취';

  const handleDetailClose = () => {
    setSelectedDetail(null);
  };

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 px-6 py-8 pb-24 overflow-y-auto">
        <div className="max-w-md mx-auto">
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-2">
              <Calendar className="w-6 h-6 text-[#6BAF8D]" />
              <h1 className="text-[#2D3436]" style={{ fontSize: '24px' }}>
                월간 리포트
              </h1>
            </div>
            <p className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
              2026년 4월
            </p>
          </div>

          <div className="bg-gradient-to-br from-[#6BAF8D] to-[#5DA581] rounded-2xl p-6 text-white shadow-lg mb-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p style={{ fontSize: '14px', fontWeight: 400, opacity: 0.9 }}>성공률</p>
                <p style={{ fontSize: '48px', lineHeight: 1.2 }}>{successRate}%</p>
              </div>
              <div className="bg-white/20 rounded-full p-3">
                <TrendingUp className="w-7 h-7" />
              </div>
            </div>
            <p style={{ fontSize: '14px', fontWeight: 400, opacity: 0.9 }}>
              이번 달 {totalCompleted}개의 습관을 완료했어요
            </p>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-[#6BAF8D]/15 shadow-sm mb-4">
            <h3 className="text-[#2D3436] mb-4" style={{ fontSize: '16px' }}>
              이번 주 진행 상황
            </h3>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={weeklyData}>
                <XAxis
                  dataKey="day"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#6B7280', fontSize: 12 }}
                />
                <YAxis hide />
                <Bar dataKey="completed" radius={[8, 8, 0, 0]}>
                  {weeklyData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill="#6BAF8D" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-3">
            <h3 className="text-[#2D3436]" style={{ fontSize: '16px' }}>
              카테고리별 상세
            </h3>

            <button
              onClick={() => setSelectedDetail('water')}
              className="w-full bg-white rounded-2xl p-4 border border-[#6BAF8D]/15 shadow-sm flex items-center justify-between hover:border-[#6BAF8D]/40 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="bg-[#6BAF8D]/10 rounded-full p-3">
                  <Droplet className="w-5 h-5 text-[#6BAF8D]" />
                </div>
                <div className="text-left">
                  <p className="text-[#2D3436]" style={{ fontSize: '15px' }}>수분 섭취</p>
                  <p className="text-[#6B7280]" style={{ fontSize: '12px', fontWeight: 400 }}>
                    26/30 완료 · 87%
                  </p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-[#6B7280]" />
            </button>

            <button
              onClick={() => setSelectedDetail('air')}
              className="w-full bg-white rounded-2xl p-4 border border-[#6BAF8D]/15 shadow-sm flex items-center justify-between hover:border-[#6BAF8D]/40 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="bg-[#A8D5BA]/20 rounded-full p-3">
                  <Wind className="w-5 h-5 text-[#A8D5BA]" />
                </div>
                <div className="text-left">
                  <p className="text-[#2D3436]" style={{ fontSize: '15px' }}>환기</p>
                  <p className="text-[#6B7280]" style={{ fontSize: '12px', fontWeight: 400 }}>
                    22/30 완료 · 73%
                  </p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-[#6B7280]" />
            </button>

            <button
              onClick={() => setSelectedDetail('stretch')}
              className="w-full bg-white rounded-2xl p-4 border border-[#6BAF8D]/15 shadow-sm flex items-center justify-between hover:border-[#6BAF8D]/40 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="bg-[#81C784]/20 rounded-full p-3">
                  <Sparkles className="w-5 h-5 text-[#81C784]" />
                </div>
                <div className="text-left">
                  <p className="text-[#2D3436]" style={{ fontSize: '15px' }}>스트레칭</p>
                  <p className="text-[#6B7280]" style={{ fontSize: '12px', fontWeight: 400 }}>
                    24/30 완료 · 80%
                  </p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-[#6B7280]" />
            </button>

            <button
              onClick={() => setSelectedDetail('walk')}
              className="w-full bg-white rounded-2xl p-4 border border-[#6BAF8D]/15 shadow-sm flex items-center justify-between hover:border-[#6BAF8D]/40 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="bg-[#4CAF50]/20 rounded-full p-3">
                  <Footprints className="w-5 h-5 text-[#4CAF50]" />
                </div>
                <div className="text-left">
                  <p className="text-[#2D3436]" style={{ fontSize: '15px' }}>산책</p>
                  <p className="text-[#6B7280]" style={{ fontSize: '12px', fontWeight: 400 }}>
                    18/30 완료 · 60%
                  </p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-[#6B7280]" />
            </button>
          </div>
        </div>
      </div>

      <BottomNav />

      {selectedDetail && (
        <DetailModal
          isOpen={!!selectedDetail}
          onClose={handleDetailClose}
          title={categoryDetailData[selectedDetail].name}
        >
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-[#6BAF8D]/10 to-[#A8D5BA]/10 rounded-2xl p-5 border border-[#6BAF8D]/20">
              <div className="flex items-center gap-4 mb-4">
                <div
                  className="rounded-full p-4"
                  style={{ backgroundColor: `${categoryDetailData[selectedDetail].color}20` }}
                >
                  {(() => {
                    const Icon = categoryDetailData[selectedDetail].icon;
                    return <Icon className="w-8 h-8" style={{ color: categoryDetailData[selectedDetail].color }} />;
                  })()}
                </div>
                <div>
                  <p className="text-[#6B7280]" style={{ fontSize: '13px', fontWeight: 400 }}>
                    이번 달 완료율
                  </p>
                  <p className="text-[#2D3436]" style={{ fontSize: '32px' }}>
                    {Math.round((categoryDetailData[selectedDetail].completed / categoryDetailData[selectedDetail].total) * 100)}%
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[#6B7280] mb-1" style={{ fontSize: '12px', fontWeight: 400 }}>
                    완료 일수
                  </p>
                  <p className="text-[#2D3436]" style={{ fontSize: '18px' }}>
                    {categoryDetailData[selectedDetail].completed}일
                  </p>
                </div>
                <div>
                  <p className="text-[#6B7280] mb-1" style={{ fontSize: '12px', fontWeight: 400 }}>
                    연속 기록
                  </p>
                  <p className="text-[#2D3436]" style={{ fontSize: '18px' }}>
                    {categoryDetailData[selectedDetail].streak}일
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-[#6BAF8D]/15 shadow-sm">
              <h4 className="text-[#2D3436] mb-4" style={{ fontSize: '16px' }}>
                주간 진행 추이
              </h4>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={categoryDetailData[selectedDetail].monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E8E6E0" />
                  <XAxis
                    dataKey="week"
                    tick={{ fill: '#6B7280', fontSize: 12 }}
                    axisLine={{ stroke: '#E8E6E0' }}
                  />
                  <YAxis
                    tick={{ fill: '#6B7280', fontSize: 12 }}
                    axisLine={{ stroke: '#E8E6E0' }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      border: '1px solid rgba(107, 175, 141, 0.15)',
                      borderRadius: '12px',
                      fontSize: '13px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="count"
                    stroke={categoryDetailData[selectedDetail].color}
                    strokeWidth={3}
                    dot={{ fill: categoryDetailData[selectedDetail].color, r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-[#6BAF8D]/15 shadow-sm">
              <h4 className="text-[#2D3436] mb-3" style={{ fontSize: '16px' }}>
                💡 실천 팁
              </h4>
              <ul className="space-y-2">
                {categoryDetailData[selectedDetail].tips.map((tip, index) => (
                  <li key={index} className="flex gap-2">
                    <span className="text-[#6BAF8D] shrink-0" style={{ fontSize: '14px' }}>•</span>
                    <p className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400, lineHeight: 1.6 }}>
                      {tip}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </DetailModal>
      )}
    </div>
  );
}
