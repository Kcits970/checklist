import { Sprout, Droplets, Sun, Award } from 'lucide-react';
import { useState, useEffect } from 'react';
import BottomNav from './BottomNav';

export default function GrowthScreen() {
  const [growthLevel, setGrowthLevel] = useState(3);
  const totalDays = 30;
  const completedDays = 18;
  const progress = (completedDays / totalDays) * 100;

  const getSproutSize = () => {
    if (growthLevel <= 2) return 'w-24 h-24';
    if (growthLevel <= 4) return 'w-32 h-32';
    return 'w-40 h-40';
  };

  const getSproutColor = () => {
    if (growthLevel <= 2) return '#A8D5BA';
    if (growthLevel <= 4) return '#6BAF8D';
    return '#4CAF50';
  };

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 px-6 py-8 pb-24">
        <div className="max-w-md mx-auto">
          <div className="mb-8">
            <h1 className="text-[#2D3436] mb-2" style={{ fontSize: '24px' }}>
              나의 성장
            </h1>
            <p className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
              작은 습관들이 모여 큰 변화를 만들어요
            </p>
          </div>

          <div className="bg-gradient-to-br from-[#F0F9F4] to-[#E8F5ED] rounded-3xl p-8 mb-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#6BAF8D]/10 rounded-full -mr-16 -mt-16" />
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-[#A8D5BA]/10 rounded-full -ml-12 -mb-12" />

            <div className="relative flex flex-col items-center py-8">
              <div className="bg-white/60 backdrop-blur-sm rounded-full p-8 mb-6 shadow-lg">
                <Sprout
                  className={`${getSproutSize()} transition-all duration-500`}
                  style={{ color: getSproutColor() }}
                  strokeWidth={1.5}
                />
              </div>

              <div className="text-center mb-4">
                <p className="text-[#6B7280] mb-1" style={{ fontSize: '14px', fontWeight: 400 }}>
                  성장 단계
                </p>
                <h2 className="text-[#2D3436]" style={{ fontSize: '28px' }}>
                  단계 {growthLevel}
                </h2>
              </div>

              <div className="w-full max-w-xs">
                <div className="flex justify-between mb-2">
                  <span className="text-[#6B7280]" style={{ fontSize: '12px', fontWeight: 400 }}>
                    {completedDays}일 완료
                  </span>
                  <span className="text-[#6B7280]" style={{ fontSize: '12px', fontWeight: 400 }}>
                    {totalDays}일 중
                  </span>
                </div>
                <div className="bg-white/60 rounded-full h-3 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-[#6BAF8D] to-[#5DA581] h-full rounded-full transition-all duration-500"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white rounded-2xl p-4 border border-[#6BAF8D]/15 shadow-sm">
              <div className="bg-[#6BAF8D]/10 rounded-full p-2.5 w-fit mb-2">
                <Droplets className="w-5 h-5 text-[#6BAF8D]" />
              </div>
              <p className="text-[#6B7280] mb-0.5" style={{ fontSize: '11px', fontWeight: 400 }}>
                오늘의 습관
              </p>
              <p className="text-[#2D3436]" style={{ fontSize: '18px' }}>
                3/4
              </p>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-[#6BAF8D]/15 shadow-sm">
              <div className="bg-[#A8D5BA]/20 rounded-full p-2.5 w-fit mb-2">
                <Sun className="w-5 h-5 text-[#6BAF8D]" />
              </div>
              <p className="text-[#6B7280] mb-0.5" style={{ fontSize: '11px', fontWeight: 400 }}>
                연속 일수
              </p>
              <p className="text-[#2D3436]" style={{ fontSize: '18px' }}>
                7일
              </p>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-[#6BAF8D]/15 shadow-sm">
              <div className="bg-[#81C784]/20 rounded-full p-2.5 w-fit mb-2">
                <Award className="w-5 h-5 text-[#6BAF8D]" />
              </div>
              <p className="text-[#6B7280] mb-0.5" style={{ fontSize: '11px', fontWeight: 400 }}>
                획득 배지
              </p>
              <p className="text-[#2D3436]" style={{ fontSize: '18px' }}>
                5개
              </p>
            </div>
          </div>

          <div className="mt-6 bg-gradient-to-r from-[#6BAF8D]/10 to-[#A8D5BA]/10 rounded-2xl p-5 border border-[#6BAF8D]/20">
            <h3 className="text-[#2D3436] mb-2" style={{ fontSize: '16px' }}>
              💡 성장 팁
            </h3>
            <p className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400, lineHeight: 1.6 }}>
              매일 작은 습관을 완료할 때마다 새싹이 자라요.
              다음 단계까지 12일 남았어요. 꾸준히 실천하면 아름다운 나무로 성장할 거예요!
            </p>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
