import { Send, Bot, User, Target, TrendingUp, Plus, Minus } from 'lucide-react';
import { useState } from 'react';
import BottomNav from './BottomNav';

const initialMessages = [
  {
    id: 1,
    type: 'ai',
    text: '안녕하세요! 오늘 하루는 어떠셨나요? 편하게 이야기 나눠요 😊',
    time: '오후 2:30',
  },
];

const quickActions = [
  { id: 1, label: '목표 수정하기', icon: Target },
  { id: 2, label: '난이도 조정', icon: TrendingUp },
  { id: 3, label: '습관 추가', icon: Plus },
  { id: 4, label: '습관 줄이기', icon: Minus },
];

export default function ChatScreen() {
  const [messages, setMessages] = useState(initialMessages);
  const [input, setInput] = useState('');
  const [showQuickActions, setShowQuickActions] = useState(true);

  const handleQuickAction = (action: string) => {
    const userMessage = {
      id: messages.length + 1,
      type: 'user',
      text: action,
      time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages([...messages, userMessage]);
    setShowQuickActions(false);

    setTimeout(() => {
      let responseText = '';
      if (action === '목표 수정하기') {
        responseText = '현재 설정된 목표를 확인해드릴게요.\n\n📊 현재 목표:\n• 하루 4개 습관 완료\n• 연속 30일 달성\n\n어떤 부분을 수정하고 싶으신가요?';
      } else if (action === '난이도 조정') {
        responseText = '현재 난이도는 "보통" 으로 설정되어 있어요.\n\n• 쉬움: 하루 2-3개 간단한 습관\n• 보통: 하루 3-4개 습관\n• 어려움: 하루 5-6개 챌린징한 습관\n\n어떤 난이도가 좋을까요?';
      } else if (action === '습관 추가') {
        responseText = '새로운 습관을 추가해드릴게요! 어떤 습관을 시작하고 싶으신가요?\n\n💡 추천 습관:\n• 아침 햇빛 보기\n• 감사 일기 쓰기\n• 명상 5분\n• 책 읽기 10분';
      } else {
        responseText = '현재 습관 목록을 줄여드릴게요. 어떤 습관이 부담스러우신가요? 편하게 말씀해주세요.';
      }

      const aiResponse = {
        id: messages.length + 2,
        type: 'ai',
        text: responseText,
        time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 1000);
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const newMessage = {
      id: messages.length + 1,
      type: 'user',
      text: input,
      time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages([...messages, newMessage]);
    setInput('');
    setShowQuickActions(false);

    setTimeout(() => {
      const aiResponse = {
        id: messages.length + 2,
        type: 'ai',
        text: '좋은 생각이에요! 작은 습관부터 시작하면 큰 변화를 만들 수 있어요. 제가 도와드릴게요.',
        time: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 flex flex-col pb-24">
        <div className="px-6 py-6 bg-white border-b border-[#6BAF8D]/15">
          <h1 className="text-[#2D3436]" style={{ fontSize: '20px' }}>
            AI 상담
          </h1>
          <p className="text-[#6B7280] mt-1" style={{ fontSize: '13px', fontWeight: 400 }}>
            언제든지 편하게 이야기 나눠요
          </p>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          <div className="max-w-md mx-auto space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.type === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div
                  className={`shrink-0 rounded-full p-2 ${
                    message.type === 'ai'
                      ? 'bg-gradient-to-br from-[#A8D5BA] to-[#6BAF8D]'
                      : 'bg-[#E8E6E0]'
                  }`}
                >
                  {message.type === 'ai' ? (
                    <Bot className="w-5 h-5 text-white" />
                  ) : (
                    <User className="w-5 h-5 text-[#6B7280]" />
                  )}
                </div>

                <div className={`flex-1 ${message.type === 'user' ? 'flex justify-end' : ''}`}>
                  <div
                    className={`inline-block rounded-2xl px-4 py-3 max-w-[80%] ${
                      message.type === 'ai'
                        ? 'bg-white border border-[#6BAF8D]/15'
                        : 'bg-gradient-to-r from-[#6BAF8D] to-[#5DA581] text-white'
                    }`}
                  >
                    <p
                      className={message.type === 'ai' ? 'text-[#2D3436]' : 'text-white'}
                      style={{ fontSize: '15px', fontWeight: 400, lineHeight: 1.5, whiteSpace: 'pre-line' }}
                    >
                      {message.text}
                    </p>
                    <p
                      className={`mt-1 ${
                        message.type === 'ai' ? 'text-[#9E9E9E]' : 'text-white/70'
                      }`}
                      style={{ fontSize: '11px', fontWeight: 400 }}
                    >
                      {message.time}
                    </p>
                  </div>
                </div>
              </div>
            ))}

            {showQuickActions && (
              <div className="space-y-3 pt-2">
                <p className="text-[#6B7280] text-center" style={{ fontSize: '13px', fontWeight: 400 }}>
                  빠른 작업
                </p>
                <div className="grid grid-cols-2 gap-3">
                  {quickActions.map((action) => {
                    const Icon = action.icon;
                    return (
                      <button
                        key={action.id}
                        onClick={() => handleQuickAction(action.label)}
                        className="bg-white border border-[#6BAF8D]/15 rounded-2xl p-4 flex flex-col items-center gap-2 hover:border-[#6BAF8D]/40 transition-all active:scale-95"
                      >
                        <div className="bg-[#6BAF8D]/10 rounded-full p-2.5">
                          <Icon className="w-5 h-5 text-[#6BAF8D]" />
                        </div>
                        <span className="text-[#2D3436]" style={{ fontSize: '13px', fontWeight: 400 }}>
                          {action.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="px-6 py-4 bg-white border-t border-[#6BAF8D]/15">
          <div className="max-w-md mx-auto flex gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="메시지를 입력하세요..."
              className="flex-1 bg-[#F5F3EE] rounded-full px-5 py-3 outline-none focus:ring-2 focus:ring-[#6BAF8D]/30 transition-all"
              style={{ fontSize: '15px', fontWeight: 400 }}
            />
            <button
              onClick={handleSend}
              className="bg-gradient-to-r from-[#6BAF8D] to-[#5DA581] text-white rounded-full p-3 shadow-md transition-all active:scale-95"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
