import { Sprout } from 'lucide-react';
import { useEffect } from 'react';
import { useNavigate } from 'react-router';

export default function SplashScreen() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/growth');
    }, 2500);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#A8D5BA] to-[#6BAF8D] flex items-center justify-center px-6">
      <div className="flex flex-col items-center gap-6 animate-[fadeIn_0.8s_ease-in-out]">
        <div className="bg-white/20 backdrop-blur-sm rounded-full p-8 shadow-lg">
          <Sprout className="w-20 h-20 text-white" strokeWidth={1.5} />
        </div>
        <h1 className="text-white tracking-wider" style={{ fontSize: '32px', fontWeight: 300, letterSpacing: '0.1em' }}>
          DailyBloom
        </h1>
      </div>
    </div>
  );
}
