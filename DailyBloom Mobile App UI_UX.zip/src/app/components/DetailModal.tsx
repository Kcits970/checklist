import { X } from 'lucide-react';
import { useEffect } from 'react';

interface DetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

export default function DetailModal({ isOpen, onClose, title, children }: DetailModalProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      <div className="relative bg-[#FDFCF9] rounded-t-3xl sm:rounded-3xl w-full max-w-[480px] max-h-[85vh] sm:max-h-[90vh] overflow-hidden animate-[slideUp_0.3s_ease-out]">
        <div className="sticky top-0 bg-[#FDFCF9] border-b border-[#6BAF8D]/15 px-6 py-4 flex items-center justify-between z-10">
          <h2 className="text-[#2D3436]" style={{ fontSize: '20px' }}>
            {title}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[#6BAF8D]/10 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-[#6B7280]" />
          </button>
        </div>

        <div className="overflow-y-auto px-6 py-6 max-h-[calc(85vh-80px)] sm:max-h-[calc(90vh-80px)]">
          {children}
        </div>
      </div>

      <style jsx>{`
        @keyframes slideUp {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}
