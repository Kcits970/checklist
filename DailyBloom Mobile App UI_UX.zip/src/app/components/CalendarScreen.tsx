import { ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { useState } from 'react';
import BottomNav from './BottomNav';

const daysOfWeek = ['일', '월', '화', '수', '목', '금', '토'];

const generateCalendar = () => {
  const days = [];
  const today = 27;
  const completedDays = [2, 5, 8, 10, 12, 15, 18, 19, 20, 22, 24, 25, 26, 27];

  for (let i = 1; i <= 30; i++) {
    days.push({
      date: i,
      isToday: i === today,
      isCompleted: completedDays.includes(i),
      isPast: i < today,
    });
  }

  return days;
};

export default function CalendarScreen() {
  const [currentMonth] = useState('2026년 4월');
  const calendarDays = generateCalendar();

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 px-6 py-8 pb-24">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-6">
            <button className="p-2 hover:bg-[#6BAF8D]/10 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6 text-[#6B7280]" />
            </button>
            <h1 className="text-[#2D3436]" style={{ fontSize: '20px' }}>
              {currentMonth}
            </h1>
            <button className="p-2 hover:bg-[#6BAF8D]/10 rounded-full transition-colors">
              <ChevronRight className="w-6 h-6 text-[#6B7280]" />
            </button>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-[#6BAF8D]/15 shadow-sm mb-4">
            <div className="grid grid-cols-7 gap-2 mb-3">
              {daysOfWeek.map((day, index) => (
                <div
                  key={day}
                  className="text-center"
                  style={{
                    fontSize: '12px',
                    fontWeight: 500,
                    color: index === 0 ? '#EF4444' : index === 6 ? '#6BAF8D' : '#6B7280',
                  }}
                >
                  {day}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-2">
              {[...Array(3)].map((_, i) => (
                <div key={`empty-${i}`} />
              ))}

              {calendarDays.map((day) => (
                <button
                  key={day.date}
                  className={`aspect-square rounded-xl flex flex-col items-center justify-center relative transition-all ${
                    day.isToday
                      ? 'bg-gradient-to-br from-[#6BAF8D] to-[#5DA581] text-white shadow-md'
                      : day.isCompleted
                      ? 'bg-[#6BAF8D]/10 text-[#6BAF8D]'
                      : 'hover:bg-[#F5F3EE]'
                  }`}
                >
                  <span
                    className={day.isToday ? 'text-white' : 'text-[#2D3436]'}
                    style={{ fontSize: '14px', fontWeight: day.isToday ? 500 : 400 }}
                  >
                    {day.date}
                  </span>
                  {day.isCompleted && !day.isToday && (
                    <Check className="w-3 h-3 text-[#6BAF8D] absolute bottom-1" strokeWidth={3} />
                  )}
                  {day.isToday && (
                    <div className="w-1 h-1 bg-white rounded-full absolute bottom-1" />
                  )}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-[#6BAF8D]/10 to-[#A8D5BA]/10 rounded-2xl p-5 border border-[#6BAF8D]/20">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[#2D3436]" style={{ fontSize: '16px' }}>
                이번 달 성과
              </h3>
              <span className="text-[#6BAF8D]" style={{ fontSize: '20px' }}>
                🎉
              </span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
                  완료한 날
                </span>
                <span className="text-[#2D3436]" style={{ fontSize: '14px' }}>
                  18일
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
                  연속 기록
                </span>
                <span className="text-[#2D3436]" style={{ fontSize: '14px' }}>
                  7일
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
                  달성률
                </span>
                <span className="text-[#6BAF8D]" style={{ fontSize: '14px' }}>
                  60%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
