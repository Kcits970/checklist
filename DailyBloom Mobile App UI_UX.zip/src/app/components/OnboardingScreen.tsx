import { Sprout, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router';

export default function OnboardingScreen() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <div className="max-w-md w-full space-y-8">
          <div className="flex justify-center">
            <div className="bg-gradient-to-br from-[#A8D5BA] to-[#6BAF8D] rounded-full p-6 shadow-lg">
              <Sprout className="w-16 h-16 text-white" strokeWidth={1.5} />
            </div>
          </div>

          <div className="text-center space-y-4">
            <h1 className="text-[#2D3436]" style={{ fontSize: '28px' }}>
              데일리블룸에 오신걸 환영해요
            </h1>
            <p className="text-[#6B7280] leading-relaxed" style={{ fontSize: '16px', fontWeight: 400 }}>
              부담 없이 작은 건강 습관을 만들어가요. 당신의 웰빙 여정을 부드럽게, 한 걸음씩 함께할게요.
            </p>
          </div>

          <div className="space-y-4 pt-4">
            <div className="flex items-start gap-4 p-4 bg-white rounded-2xl border border-[#6BAF8D]/15">
              <div className="bg-[#A8D5BA]/20 rounded-full p-2 mt-1">
                <Sparkles className="w-5 h-5 text-[#6BAF8D]" />
              </div>
              <div>
                <h3 className="text-[#2D3436] mb-1" style={{ fontSize: '16px' }}>맞춤형 습관 추천</h3>
                <p className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
                  오늘 당신의 기분에 맞는 습관을 추천해드려요
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-white rounded-2xl border border-[#6BAF8D]/15">
              <div className="bg-[#A8D5BA]/20 rounded-full p-2 mt-1">
                <Sprout className="w-5 h-5 text-[#6BAF8D]" />
              </div>
              <div>
                <h3 className="text-[#2D3436] mb-1" style={{ fontSize: '16px' }}>나만의 속도로 성장</h3>
                <p className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
                  스트레스 없이, 판단 없이 - 오직 부드러운 성장만
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6 pb-8">
        <button
          onClick={() => navigate('/status-check')}
          className="w-full bg-gradient-to-r from-[#6BAF8D] to-[#5DA581] text-white py-4 rounded-2xl shadow-lg transition-all active:scale-[0.98]"
          style={{ fontSize: '16px' }}
        >
          시작하기
        </button>
      </div>
    </div>
  );
}
