import { Battery, Cloud, Smile, Zap } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router';

const moodOptions = [
  { id: 'energized', label: '활기찬', icon: Zap, color: '#6BAF8D' },
  { id: 'calm', label: '평온한', icon: Cloud, color: '#A8D5BA' },
  { id: 'happy', label: '행복한', icon: Smile, color: '#81C784' },
  { id: 'tired', label: '피곤한', icon: Battery, color: '#9E9E9E' },
];

export default function StatusCheckScreen() {
  const [selected, setSelected] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleContinue = () => {
    if (selected) {
      navigate('/recommendations');
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 px-6 py-8">
        <div className="max-w-md mx-auto">
          <div className="mb-8">
            <h1 className="text-[#2D3436] mb-2" style={{ fontSize: '24px' }}>
              오늘 기분이 어떠세요?
            </h1>
            <p className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
              당신에게 맞는 습관을 추천해드릴게요
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {moodOptions.map((option) => {
              const Icon = option.icon;
              const isSelected = selected === option.id;

              return (
                <button
                  key={option.id}
                  onClick={() => setSelected(option.id)}
                  className={`p-6 rounded-2xl border-2 transition-all ${
                    isSelected
                      ? 'border-[#6BAF8D] bg-[#6BAF8D]/5 shadow-md'
                      : 'border-[#6BAF8D]/15 bg-white'
                  }`}
                >
                  <div className="flex flex-col items-center gap-3">
                    <div
                      className="rounded-full p-4"
                      style={{ backgroundColor: `${option.color}20` }}
                    >
                      <Icon className="w-8 h-8" style={{ color: option.color }} strokeWidth={1.5} />
                    </div>
                    <span className="text-[#2D3436]" style={{ fontSize: '16px' }}>
                      {option.label}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="p-6 pb-8">
        <button
          onClick={handleContinue}
          disabled={!selected}
          className={`w-full py-4 rounded-2xl transition-all ${
            selected
              ? 'bg-gradient-to-r from-[#6BAF8D] to-[#5DA581] text-white shadow-lg active:scale-[0.98]'
              : 'bg-[#E8E6E0] text-[#9E9E9E] cursor-not-allowed'
          }`}
          style={{ fontSize: '16px' }}
        >
          계속하기
        </button>
      </div>
    </div>
  );
}
