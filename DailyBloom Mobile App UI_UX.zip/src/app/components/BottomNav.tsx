import { MessageCircle, Calendar, Sprout, ListChecks, BarChart3 } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router';

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#6BAF8D]/15 shadow-[0_-4px_12px_rgba(0,0,0,0.05)]">
      <div className="max-w-[480px] mx-auto px-4 py-2 relative">
        <div className="flex items-end justify-around">
          <button
            onClick={() => navigate('/chat')}
            className={`flex flex-col items-center gap-1 py-2 px-3 ${
              isActive('/chat') ? 'text-[#6BAF8D]' : 'text-[#9E9E9E]'
            }`}
          >
            <MessageCircle className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '11px', fontWeight: 500 }}>AI 채팅</span>
          </button>

          <button
            onClick={() => navigate('/calendar')}
            className={`flex flex-col items-center gap-1 py-2 px-3 ${
              isActive('/calendar') ? 'text-[#6BAF8D]' : 'text-[#9E9E9E]'
            }`}
          >
            <Calendar className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '11px', fontWeight: 500 }}>캘린더</span>
          </button>

          <button
            onClick={() => navigate('/growth')}
            className="flex flex-col items-center -mt-8"
          >
            <div className={`rounded-full p-4 shadow-lg transition-all ${
              isActive('/growth')
                ? 'bg-gradient-to-br from-[#6BAF8D] to-[#5DA581]'
                : 'bg-gradient-to-br from-[#A8D5BA] to-[#6BAF8D]'
            }`}>
              <Sprout className="w-8 h-8 text-white" strokeWidth={2} />
            </div>
            <span className="text-[#6BAF8D] mt-1" style={{ fontSize: '11px', fontWeight: 500 }}>
              성장
            </span>
          </button>

          <button
            onClick={() => navigate('/today')}
            className={`flex flex-col items-center gap-1 py-2 px-3 ${
              isActive('/today') ? 'text-[#6BAF8D]' : 'text-[#9E9E9E]'
            }`}
          >
            <ListChecks className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '11px', fontWeight: 500 }}>오늘</span>
          </button>

          <button
            onClick={() => navigate('/report')}
            className={`flex flex-col items-center gap-1 py-2 px-3 ${
              isActive('/report') ? 'text-[#6BAF8D]' : 'text-[#9E9E9E]'
            }`}
          >
            <BarChart3 className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '11px', fontWeight: 500 }}>리포트</span>
          </button>
        </div>
      </div>
    </div>
  );
}
