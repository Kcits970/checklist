import { Award, TrendingUp, Home, BarChart3, ListTodo, Calendar } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from 'recharts';
import { useNavigate } from 'react-router';

const weeklyData = [
  { day: 'Mon', completed: 3 },
  { day: 'Tue', completed: 4 },
  { day: 'Wed', completed: 2 },
  { day: 'Thu', completed: 4 },
  { day: 'Fri', completed: 3 },
  { day: 'Sat', completed: 4 },
  { day: 'Sun', completed: 4 },
];

export default function MonthlyReportScreen() {
  const navigate = useNavigate();
  const successRate = 82;
  const totalCompleted = 94;
  const bestCategory = 'Hydration';

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 px-6 py-8 pb-24 overflow-y-auto">
        <div className="max-w-md mx-auto">
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-2">
              <Calendar className="w-6 h-6 text-[#6BAF8D]" />
              <h1 className="text-[#2D3436]" style={{ fontSize: '24px' }}>
                Monthly Report
              </h1>
            </div>
            <p className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
              April 2026
            </p>
          </div>

          <div className="bg-gradient-to-br from-[#6BAF8D] to-[#5DA581] rounded-2xl p-6 text-white shadow-lg mb-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p style={{ fontSize: '14px', fontWeight: 400, opacity: 0.9 }}>Success Rate</p>
                <p style={{ fontSize: '48px', lineHeight: 1.2 }}>{successRate}%</p>
              </div>
              <div className="bg-white/20 rounded-full p-3">
                <TrendingUp className="w-7 h-7" />
              </div>
            </div>
            <p style={{ fontSize: '14px', fontWeight: 400, opacity: 0.9 }}>
              {totalCompleted} habits completed this month
            </p>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-[#6BAF8D]/15 shadow-sm mb-4">
            <h3 className="text-[#2D3436] mb-4" style={{ fontSize: '16px' }}>
              This Week's Progress
            </h3>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={weeklyData}>
                <XAxis
                  dataKey="day"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#6B7280', fontSize: 12 }}
                />
                <YAxis hide />
                <Bar dataKey="completed" radius={[8, 8, 0, 0]}>
                  {weeklyData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill="#6BAF8D" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-[#6BAF8D]/15 shadow-sm">
              <div className="bg-[#6BAF8D]/10 rounded-full p-3 w-fit mb-3">
                <Award className="w-6 h-6 text-[#6BAF8D]" />
              </div>
              <p className="text-[#6B7280] mb-1" style={{ fontSize: '12px', fontWeight: 400 }}>
                Best Category
              </p>
              <p className="text-[#2D3436]" style={{ fontSize: '16px' }}>
                {bestCategory}
              </p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-[#6BAF8D]/15 shadow-sm">
              <div className="bg-[#A8D5BA]/20 rounded-full p-3 w-fit mb-3">
                <TrendingUp className="w-6 h-6 text-[#6BAF8D]" />
              </div>
              <p className="text-[#6B7280] mb-1" style={{ fontSize: '12px', fontWeight: 400 }}>
                Improvement
              </p>
              <p className="text-[#2D3436]" style={{ fontSize: '16px' }}>
                +12%
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#6BAF8D]/15 px-6 py-4 shadow-[0_-4px_12px_rgba(0,0,0,0.05)]">
        <div className="max-w-md mx-auto flex justify-around">
          <button className="flex flex-col items-center gap-1 text-[#6B7280]">
            <Home className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '12px', fontWeight: 500 }}>Home</span>
          </button>
          <button
            onClick={() => navigate('/daily-checklist')}
            className="flex flex-col items-center gap-1 text-[#6B7280]"
          >
            <ListTodo className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '12px', fontWeight: 500 }}>Today</span>
          </button>
          <button
            onClick={() => navigate('/monthly-report')}
            className="flex flex-col items-center gap-1 text-[#6BAF8D]"
          >
            <BarChart3 className="w-6 h-6" strokeWidth={2} />
            <span style={{ fontSize: '12px', fontWeight: 500 }}>Report</span>
          </button>
        </div>
      </div>
    </div>
  );
}
