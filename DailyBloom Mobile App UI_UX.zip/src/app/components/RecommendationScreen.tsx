import { Clock, Droplet, Signal, Sparkles, Wind, Footprints } from 'lucide-react';
import { useNavigate } from 'react-router';

const habits = [
  {
    id: 1,
    title: '물 마시기',
    reason: '수분 보충으로 활력 충전',
    time: '1분',
    difficulty: '쉬움',
    icon: Droplet,
    color: '#6BAF8D',
  },
  {
    id: 2,
    title: '창문 열기',
    reason: '신선한 공기로 집중력 향상',
    time: '30초',
    difficulty: '쉬움',
    icon: Wind,
    color: '#A8D5BA',
  },
  {
    id: 3,
    title: '1분 스트레칭',
    reason: '근육 긴장 완화',
    time: '1분',
    difficulty: '쉬움',
    icon: Sparkles,
    color: '#81C784',
  },
  {
    id: 4,
    title: '짧은 산책',
    reason: '기분 전환과 혈액 순환 개선',
    time: '5분',
    difficulty: '보통',
    icon: Footprints,
    color: '#4CAF50',
  },
];

export default function RecommendationScreen() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 px-6 py-8">
        <div className="max-w-md mx-auto">
          <div className="mb-6">
            <h1 className="text-[#2D3436] mb-2" style={{ fontSize: '24px' }}>
              오늘의 추천 습관
            </h1>
            <p className="text-[#6B7280]" style={{ fontSize: '14px', fontWeight: 400 }}>
              당신의 에너지 레벨에 맞는 작은 습관들이에요
            </p>
          </div>

          <div className="space-y-4">
            {habits.map((habit) => {
              const Icon = habit.icon;

              return (
                <div
                  key={habit.id}
                  className="bg-white rounded-2xl p-5 border border-[#6BAF8D]/15 shadow-sm"
                >
                  <div className="flex gap-4">
                    <div
                      className="rounded-xl p-3 shrink-0"
                      style={{ backgroundColor: `${habit.color}20` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: habit.color }} strokeWidth={1.5} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <h3 className="text-[#2D3436] mb-1" style={{ fontSize: '16px' }}>
                        {habit.title}
                      </h3>
                      <p className="text-[#6B7280] mb-3" style={{ fontSize: '14px', fontWeight: 400 }}>
                        {habit.reason}
                      </p>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-4 h-4 text-[#6B7280]" />
                          <span className="text-[#6B7280]" style={{ fontSize: '12px', fontWeight: 400 }}>
                            {habit.time}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Signal className="w-4 h-4 text-[#6B7280]" />
                          <span className="text-[#6B7280]" style={{ fontSize: '12px', fontWeight: 400 }}>
                            {habit.difficulty}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="p-6 pb-8">
        <button
          onClick={() => navigate('/today')}
          className="w-full bg-gradient-to-r from-[#6BAF8D] to-[#5DA581] text-white py-4 rounded-2xl shadow-lg transition-all active:scale-[0.98]"
          style={{ fontSize: '16px' }}
        >
          오늘의 습관 시작하기
        </button>
      </div>
    </div>
  );
}
