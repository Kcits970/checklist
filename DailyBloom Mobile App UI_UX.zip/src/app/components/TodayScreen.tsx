import { CheckCircle2, Circle, Flame } from 'lucide-react';
import { useState } from 'react';
import BottomNav from './BottomNav';

const todayHabits = [
  { id: 1, title: '물 마시기', completed: false },
  { id: 2, title: '창문 열기', completed: false },
  { id: 3, title: '1분 스트레칭', completed: false },
  { id: 4, title: '짧은 산책', completed: false },
];

export default function TodayScreen() {
  const [habits, setHabits] = useState(todayHabits);

  const toggleHabit = (id: number) => {
    setHabits(habits.map(h => h.id === id ? { ...h, completed: !h.completed } : h));
  };

  const completedCount = habits.filter(h => h.completed).length;
  const totalCount = habits.length;
  const progress = (completedCount / totalCount) * 100;
  const streak = 7;

  return (
    <div className="min-h-screen bg-[#FDFCF9] flex flex-col">
      <div className="flex-1 px-6 py-8 pb-24">
        <div className="max-w-md mx-auto">
          <div className="mb-6">
            <h1 className="text-[#2D3436] mb-4" style={{ fontSize: '24px' }}>
              오늘의 습관
            </h1>

            <div className="bg-gradient-to-br from-[#6BAF8D] to-[#5DA581] rounded-2xl p-5 text-white shadow-lg mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p style={{ fontSize: '14px', fontWeight: 400, opacity: 0.9 }}>오늘의 진행률</p>
                  <p style={{ fontSize: '28px' }}>
                    {completedCount} / {totalCount}
                  </p>
                </div>
                <div className="flex items-center gap-2 bg-white/20 rounded-full px-4 py-2">
                  <Flame className="w-5 h-5" />
                  <span style={{ fontSize: '16px' }}>{streak}일 연속</span>
                </div>
              </div>

              <div className="bg-white/20 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-white h-full rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {habits.map((habit) => (
              <button
                key={habit.id}
                onClick={() => toggleHabit(habit.id)}
                className={`w-full p-4 rounded-2xl border-2 transition-all flex items-center gap-4 ${
                  habit.completed
                    ? 'bg-[#6BAF8D]/5 border-[#6BAF8D]'
                    : 'bg-white border-[#6BAF8D]/15'
                }`}
              >
                {habit.completed ? (
                  <CheckCircle2 className="w-6 h-6 text-[#6BAF8D] shrink-0" strokeWidth={2} />
                ) : (
                  <Circle className="w-6 h-6 text-[#6B7280] shrink-0" strokeWidth={2} />
                )}
                <span
                  className={`text-left ${
                    habit.completed ? 'text-[#6B7280] line-through' : 'text-[#2D3436]'
                  }`}
                  style={{ fontSize: '16px' }}
                >
                  {habit.title}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
