import { BrowserRouter, Routes, Route, Navigate } from 'react-router';
import SplashScreen from './components/SplashScreen';
import OnboardingScreen from './components/OnboardingScreen';
import StatusCheckScreen from './components/StatusCheckScreen';
import RecommendationScreen from './components/RecommendationScreen';
import GrowthScreen from './components/GrowthScreen';
import TodayScreen from './components/TodayScreen';
import ReportScreen from './components/ReportScreen';
import ChatScreen from './components/ChatScreen';
import CalendarScreen from './components/CalendarScreen';

export default function App() {
  return (
    <BrowserRouter>
      <div className="size-full max-w-[480px] mx-auto bg-[#FDFCF9]">
        <Routes>
          <Route path="/" element={<SplashScreen />} />
          <Route path="/onboarding" element={<OnboardingScreen />} />
          <Route path="/status-check" element={<StatusCheckScreen />} />
          <Route path="/recommendations" element={<RecommendationScreen />} />
          <Route path="/growth" element={<GrowthScreen />} />
          <Route path="/today" element={<TodayScreen />} />
          <Route path="/report" element={<ReportScreen />} />
          <Route path="/chat" element={<ChatScreen />} />
          <Route path="/calendar" element={<CalendarScreen />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}