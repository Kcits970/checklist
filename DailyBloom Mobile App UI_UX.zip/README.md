
  # DailyBloom Mobile App UI/UX

  This is a code bundle for DailyBloom Mobile App UI/UX. The original project is available at https://www.figma.com/design/uV10JeRviQU7UhlIkvuzdD/DailyBloom-Mobile-App-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  